#define STB_IMAGE_IMPLEMENTATION
// #define STB_IMAGE_STATIC
#define STB_IMAGE_FLOAT // 允许加载 HDR 图像
#include "stb_image.h"