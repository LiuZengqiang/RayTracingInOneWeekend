﻿#include <cstdio>
#include <iostream>
#include <vector>

#include "Mesh.hpp"
#include "Model.hpp"
#include "Shader.hpp"
#include "Sphere.hpp"
#include "glm/ext/matrix_clip_space.hpp"
#include "glm/ext/matrix_transform.hpp"
#include "glm/fwd.hpp"
#include "glm/trigonometric.hpp"
#include "stb_image.h"
#include "GLFW/glfw3.h"

void framebuffer_size_callback(GLFWwindow *window, int width, int height);

void processInput(GLFWwindow *window);

unsigned int SCR_WIDTH = 800;
unsigned int SCR_HEIGHT = 600;
unsigned int maxNodes = SCR_WIDTH * SCR_HEIGHT * 20;

float view_rotate = 45.0f;
// camera view matrix
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 2.0f);
glm::vec3 cameraLookAt = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

// camera perspective matrix
float cameraZoom = 90.0f;
float cameraNearPlane = 0.1f; // near
float cameraFarPlane = 10.0f; // far
// light
glm::vec3 lightPos = glm::vec3(2.0f, 2.0f, 0.0f);
// k: ambient, diffues, specular
glm::vec3 k = glm::vec3(0.4f, 0.4f, 0.2f);

struct ListNode {
  glm::vec4 color;
  GLfloat depth;
  GLuint next;
};

int main() {

  glfwInit();
  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
  glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

  glfwWindowHint(GLFW_SAMPLES, 4);

  GLFWwindow *window =
      glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
  if (window == NULL) {
    std::cout << "Failed to create GLFW window" << std::endl;
    glfwTerminate();
    return -1;
  }

  glfwMakeContextCurrent(window);

  glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

  if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
    std::cout << "Failed to initialize GLAD" << std::endl;
    return -1;
  }

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);
  glEnable(GL_MULTISAMPLE);

  Shader depthPeelingInitShader("../resources/depth_peeling_init.vert",
                                "../resources/depth_peeling_init.frag");

  Shader depthPeelingRenderShader("../resources/depth_peeling_render.vert",
                                  "../resources/depth_peeling_render.frag");

  Shader depthPeelingBlendShader("../resources/depth_peeling_blend.vert",
                                 "../resources/depth_peeling_blend.frag");

  Shader depthPeelingFinalShader("../resources/depth_peeling_final.vert",
                                 "../resources/depth_peeling_final.frag");

  Shader quadShader("../resources/quad.vert", "../resources/quad.frag");

  Model quad = Model("../resources/models/quad/quad.obj");
  Model spot = Model("../resources/models/spot/spot.obj");

  Texture texture_window_r = Texture("../resources/models/quad/window-r.png");
  Texture texture_window_g = Texture("../resources/models/quad/window-g.png");
  Texture texture_window_b = Texture("../resources/models/quad/window-b.png");
  Texture texture_spot = Texture("../resources/models/spot/spot.png");

  GLuint atomic_buffer;
  GLuint linked_list_buffer;
  GLuint headPtrTexture;

  GLuint zero = 0;
  GLuint clearBuf;

  glGenBuffers(1, &atomic_buffer);
  glGenBuffers(1, &linked_list_buffer);

  GLint nodeSize = 5 * sizeof(GLfloat) + sizeof(GLuint);
  glBindBufferBase(GL_ATOMIC_COUNTER_BUFFER, 0, atomic_buffer);
  glBufferData(GL_ATOMIC_COUNTER_BUFFER, sizeof(GLuint), NULL, GL_DYNAMIC_DRAW);
  glBufferSubData(GL_ATOMIC_COUNTER_BUFFER, 0, sizeof(GLuint), &zero);

  // // The buffer of linked lists
  glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, linked_list_buffer);
  glBufferData(GL_SHADER_STORAGE_BUFFER, maxNodes * nodeSize, NULL,
               GL_DYNAMIC_DRAW);

  // // The buffer for the head pointers, as an image texture
  glGenTextures(1, &headPtrTexture);
  glBindTexture(GL_TEXTURE_2D, headPtrTexture);
  glTexStorage2D(GL_TEXTURE_2D, 1, GL_R32UI, SCR_WIDTH, SCR_HEIGHT);
  glBindImageTexture(0, headPtrTexture, 0, GL_FALSE, 0, GL_READ_WRITE,
                     GL_R32UI);
  glBindTexture(GL_TEXTURE_2D, 0);

  vector<GLuint> headPtrClearBuf(SCR_WIDTH * SCR_HEIGHT, 0xffffffff);
  glGenBuffers(1, &clearBuf);
  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, clearBuf);

  glBufferData(GL_PIXEL_UNPACK_BUFFER, headPtrClearBuf.size() * sizeof(GLuint),
               &headPtrClearBuf[0], GL_STATIC_COPY);

  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, clearBuf);
  glBindTexture(GL_TEXTURE_2D, headPtrTexture);
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, SCR_WIDTH, SCR_HEIGHT, GL_RED_INTEGER,
                  GL_UNSIGNED_INT, NULL);

  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);

  // rgba_0_FBO
  unsigned int rgba_0_FBO;
  glGenFramebuffers(1, &rgba_0_FBO);

  // rgba_1_FBO
  unsigned int rgba_1_FBO;
  glGenFramebuffers(1, &rgba_1_FBO);

  unsigned int rgba_0_Texture;
  glGenTextures(1, &rgba_0_Texture);
  glBindTexture(GL_TEXTURE_2D, rgba_0_Texture);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, SCR_WIDTH, SCR_HEIGHT, 0, GL_RGBA,
               GL_HALF_FLOAT, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_2D, 0);

  unsigned int rgba_1_Texture;
  glGenTextures(1, &rgba_1_Texture);
  glBindTexture(GL_TEXTURE_2D, rgba_1_Texture);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, SCR_WIDTH, SCR_HEIGHT, 0, GL_RGBA,
               GL_HALF_FLOAT, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_2D, 0);

  unsigned int rgba_0_DepthTexture;
  glGenTextures(1, &rgba_0_DepthTexture);
  glBindTexture(GL_TEXTURE_2D, rgba_0_DepthTexture);

  glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, SCR_WIDTH, SCR_HEIGHT,
               0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_2D, 0);

  unsigned int rgba_1_DepthTexture;
  glGenTextures(1, &rgba_1_DepthTexture);
  glBindTexture(GL_TEXTURE_2D, rgba_1_DepthTexture);

  glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, SCR_WIDTH, SCR_HEIGHT,
               0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_2D, 0);

  glBindFramebuffer(GL_FRAMEBUFFER, rgba_0_FBO);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                         rgba_0_Texture, 0);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
                         rgba_0_DepthTexture, 0);
  GLenum drawBuffers[] = {GL_COLOR_ATTACHMENT0, GL_DEPTH_ATTACHMENT};
  glDrawBuffers(2, drawBuffers);

  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    std::cout << "ERROR::FRAMEBUFFER:: Opaque framebuffer is not complete!"
              << std::endl;

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  glBindFramebuffer(GL_FRAMEBUFFER, rgba_1_FBO);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                         rgba_1_Texture, 0);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
                         rgba_1_DepthTexture, 0);
  // drawBuffers[] = {GL_COLOR_ATTACHMENT0, GL_DEPTH_ATTACHMENT};
  glDrawBuffers(2, drawBuffers);

  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    std::cout << "ERROR::FRAMEBUFFER:: Opaque framebuffer is not complete!"
              << std::endl;

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  unsigned int oitTexture;
  glGenTextures(1, &oitTexture);
  glBindTexture(GL_TEXTURE_2D, oitTexture);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, SCR_WIDTH, SCR_HEIGHT, 0, GL_RGBA,
               GL_HALF_FLOAT, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_2D, 0);

  unsigned int oitRenderFBO;
  glGenFramebuffers(1, &oitRenderFBO);
  glBindFramebuffer(GL_FRAMEBUFFER, oitRenderFBO);

  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                         oitTexture, 0);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
                         rgba_0_DepthTexture, 0);

  GLenum drawBuffersOIT[] = {GL_COLOR_ATTACHMENT0, GL_DEPTH_ATTACHMENT};
  glDrawBuffers(2, drawBuffersOIT);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    std::cout << "ERROR::FRAMEBUFFER:: Opaque framebuffer is not complete!"
              << std::endl;
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  auto cameraModel = glm::mat4(1.0f);
  auto cameraView = glm::mat4(1.0f);
  auto cameraProjection = glm::mat4(1.0f);

  glViewport(0, 0, SCR_WIDTH, SCR_HEIGHT);
  // glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
  glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  while (!glfwWindowShouldClose(window)) {

    // view_rotate += 1.0f;
    // input
    // -----
    processInput(window);

    /* Pass 1 */

    glBindFramebuffer(GL_FRAMEBUFFER, rgba_0_FBO);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
                           rgba_0_DepthTexture, 0);

    glClearColor(0, 0, 0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    // glDisable(GL_CULL_FACE);
    glEnable(GL_CULL_FACE);

    glDepthMask(GL_TRUE);

    depthPeelingInitShader.use();
    depthPeelingInitShader.setVec3("cameraPos", cameraPos);
    depthPeelingInitShader.setVec3("lightPos", lightPos);
    depthPeelingInitShader.setVec3("k", k);

    cameraView = glm::mat4(1.0f);
    cameraView =
        glm::lookAt(2.0f * glm::vec3(glm::sin(glm::radians(view_rotate)), 0.0f,
                                     glm::cos(glm::radians(view_rotate))),
                    glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    cameraProjection = glm::perspective(
        glm::radians(90.0f), (float)(SCR_WIDTH) / (float)(SCR_HEIGHT), 0.1f,
        100.0f);

    depthPeelingInitShader.use();
    // model, view, projection
    cameraModel = glm::mat4(1.0f);
    cameraModel = glm::translate(cameraModel, glm::vec3(-0.5f, 0.0f, 0.8f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(1.0f, 0.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 1.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 0.0f, 1.0f));
    cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

    depthPeelingInitShader.setVec3("cameraPos", cameraPos);
    depthPeelingInitShader.setVec3("lightPos", lightPos);
    depthPeelingInitShader.setVec3("k", k);
    depthPeelingInitShader.setUint("MaxNodes", maxNodes);
    depthPeelingInitShader.setMat4("model", cameraModel);
    depthPeelingInitShader.setMat4("view", cameraView);
    depthPeelingInitShader.setMat4("projection", cameraProjection);

    quad.Draw(depthPeelingInitShader, rgba_0_FBO,
              {{"texture_diffuse", texture_window_r.id}}, {}, GL_TRIANGLES,
              {false, false});

    // model, view, projection
    cameraModel = glm::mat4(1.0f);
    cameraModel = glm::translate(cameraModel, glm::vec3(0.2f, -0.5f, -1.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(1.0f, 0.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 1.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 0.0f, 1.0f));
    cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

    depthPeelingInitShader.setMat4("model", cameraModel);
    depthPeelingInitShader.setMat4("view", cameraView);
    depthPeelingInitShader.setMat4("projection", cameraProjection);

    quad.Draw(depthPeelingInitShader, rgba_0_FBO,
              {{"texture_diffuse", texture_window_g.id}}, {}, GL_TRIANGLES,
              {false, false});

    // // model, view, projection
    cameraModel = glm::mat4(1.0f);
    cameraModel = glm::translate(cameraModel, glm::vec3(0.2f, 0.0f, -0.5f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(1.0f, 0.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 1.0f, 0.0f));
    cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                              glm::vec3(0.0f, 0.0f, 1.0f));
    cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

    depthPeelingInitShader.setMat4("model", cameraModel);
    depthPeelingInitShader.setMat4("view", cameraView);
    depthPeelingInitShader.setMat4("projection", cameraProjection);

    quad.Draw(depthPeelingInitShader, rgba_0_FBO,
              {{"texture_diffuse", texture_window_b.id}}, {}, GL_TRIANGLES,
              {false, false});

    // PASS 2
    int input_depth_texture = 0;
    int output_depth_texture = 1;
    GLuint queryId;
    glGenQueries(1, &queryId);
    GLint available = 0;
    GLuint sampleCount = 0;

    int c = 0;
    do {
      break;
      glBindFramebuffer(GL_FRAMEBUFFER, rgba_1_FBO);
      glFramebufferTexture2D(
          GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
          output_depth_texture ? rgba_1_DepthTexture : rgba_0_DepthTexture, 0);

      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glBindFramebuffer(GL_FRAMEBUFFER, 0);

      glBeginQuery(GL_SAMPLES_PASSED, queryId);

      // GL_SAMPLES_PASSED_ARB
      depthPeelingRenderShader.use();
      depthPeelingRenderShader.setVec3("cameraPos", cameraPos);
      depthPeelingRenderShader.setVec3("lightPos", lightPos);
      depthPeelingRenderShader.setVec3("k", k);

      // model, view, projection


      cameraView = glm::mat4(1.0f);
      cameraView = glm::lookAt(
          2.0f * glm::vec3(glm::sin(glm::radians(view_rotate)), 0.0f,
                           glm::cos(glm::radians(view_rotate))),
          glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
      cameraProjection = glm::perspective(
          glm::radians(90.0f), (float)(SCR_WIDTH) / (float)(SCR_HEIGHT), 0.1f,
          100.0f);

      depthPeelingRenderShader.use();
      // model, view, projection
      cameraModel = glm::mat4(1.0f);
      cameraModel = glm::translate(cameraModel, glm::vec3(-0.5f, 0.0f, 0.8f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(1.0f, 0.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 1.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 0.0f, 1.0f));
      cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

      depthPeelingRenderShader.setVec3("cameraPos", cameraPos);
      depthPeelingRenderShader.setVec3("lightPos", lightPos);
      depthPeelingRenderShader.setVec3("k", k);
      depthPeelingRenderShader.setUint("MaxNodes", maxNodes);
      depthPeelingRenderShader.setMat4("model", cameraModel);
      depthPeelingRenderShader.setMat4("view", cameraView);
      depthPeelingRenderShader.setMat4("projection", cameraProjection);

      quad.Draw(depthPeelingRenderShader, rgba_1_FBO,
                {{"texture_diffuse", texture_window_r.id},
                 {"texture_depth", input_depth_texture ? rgba_1_DepthTexture
                                                       : rgba_0_DepthTexture}},
                {}, GL_TRIANGLES, {false, false});

      // model, view, projection
      cameraModel = glm::mat4(1.0f);
      cameraModel = glm::translate(cameraModel, glm::vec3(0.2f, -0.5f, -1.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(1.0f, 0.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 1.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 0.0f, 1.0f));
      cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

      depthPeelingRenderShader.setMat4("model", cameraModel);
      depthPeelingRenderShader.setMat4("view", cameraView);
      depthPeelingRenderShader.setMat4("projection", cameraProjection);

      quad.Draw(depthPeelingRenderShader, rgba_1_FBO,
                {{"texture_diffuse", texture_window_g.id},
                 {"texture_depth", input_depth_texture ? rgba_1_DepthTexture
                                                       : rgba_0_DepthTexture}},
                {}, GL_TRIANGLES, {false, false});

      // // model, view, projection
      cameraModel = glm::mat4(1.0f);
      cameraModel = glm::translate(cameraModel, glm::vec3(0.2f, 0.0f, -0.5f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(1.0f, 0.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 1.0f, 0.0f));
      cameraModel = glm::rotate(cameraModel, glm::radians(0.0f),
                                glm::vec3(0.0f, 0.0f, 1.0f));
      cameraModel = glm::scale(cameraModel, glm::vec3(0.5f, 0.5f, 0.5f));

      depthPeelingRenderShader.setMat4("model", cameraModel);
      depthPeelingRenderShader.setMat4("view", cameraView);
      depthPeelingRenderShader.setMat4("projection", cameraProjection);

      quad.Draw(depthPeelingRenderShader, rgba_1_FBO,
                {{"texture_diffuse", texture_window_b.id},
                 {"texture_depth", input_depth_texture ? rgba_1_DepthTexture
                                                       : rgba_0_DepthTexture}},
                {}, GL_TRIANGLES, {false, false});

      glEndQuery(GL_SAMPLES_PASSED);

      while (!available) {
        glGetQueryObjectiv(queryId, GL_QUERY_RESULT_AVAILABLE, &available);
      }

      if (available) {

        glGetQueryObjectuiv(queryId, GL_QUERY_RESULT, &sampleCount);
        std::cout << "Samples passed: " << sampleCount << std::endl;
      }

      // blend
      // break;

      // depthPeelingBlendShader.use();
      glEnable(GL_BLEND);
      glDepthMask(GL_FALSE);

      glBlendFuncSeparate(GL_DST_ALPHA, GL_ONE, GL_ZERO,
                          GL_ONE_MINUS_SRC_ALPHA);

      quadShader.use();
      quad.Draw(quadShader, rgba_0_FBO, {{"texture_diffuse", rgba_0_Texture}},
                {}, GL_TRIANGLES, {false, true});

      input_depth_texture = (input_depth_texture + 1) % 2;
      output_depth_texture = (output_depth_texture + 1) % 2;
      glDisable(GL_BLEND);
      glDepthMask(GL_TRUE);

      c++;
      if (c >= 1) {
        break;
      }
    } while (sampleCount > 0);

    cout << "c:" << c << "\n";
    // // blend background
    // depthPeelingFinalShader.use();
    // depthPeelingFinalShader.setVec3("background_color",
    //                                 glm::vec3(0.2f, 0.3f, 0.3f));

    // // glDisable(GL_DEPTH_TEST);
    // quad.Draw(depthPeelingFinalShader, 0, {{"texture_diffuse", rgba_0_Texture}},
    //           {}, GL_TRIANGLES, {true, true});

    quadShader.use();
    quad.Draw(quadShader, 0, {{"texture_diffuse", rgba_0_Texture}}, {},
              GL_TRIANGLES, {true, true});

    // quadShader.use();
    // quad.Draw(quadShader, 0, {{"texture_diffuse", rgba_0_DepthTexture}}, {},
    //           GL_TRIANGLES, {true, true});
    glfwSwapBuffers(window);
    glfwPollEvents();
  }

  /************************************/
  glfwTerminate();
  /************************************/
  return 0;
}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
  SCR_WIDTH = width;
  SCR_HEIGHT = height;
  glViewport(0, 0, width, height);
}

void processInput(GLFWwindow *window) {

  if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
    glfwSetWindowShouldClose(window, true);
  } else if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
    view_rotate += 1.0f;
  } else if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
    view_rotate -= 1.0f;
  }
}